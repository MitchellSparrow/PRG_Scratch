# PRG Scratch - PyGame Project
A repository for the pygame group project for programming.

## TEAM Scratch

Mitchell Sparrow        20274110    psxms17
Arundeep Chatha 	    10350557	psxac11
Daniel Audcent		    20316239	psxda7 


## Installation Instructions

Ensure that Python>=3.7 and Pygame 2.0 is installed on your device

Run the main.py executable

Enjoy!



